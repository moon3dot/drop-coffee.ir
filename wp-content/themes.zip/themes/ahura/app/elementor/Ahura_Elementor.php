<?php
namespace ahura\app\elementor;

if(!class_exists('\Elementor\Plugin'))
{
    return false;
}
class Ahura_Elementor extends \Elementor\Plugin
{

}