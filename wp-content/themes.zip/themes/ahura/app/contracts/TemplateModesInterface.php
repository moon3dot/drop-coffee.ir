<?php
namespace ahura\app\contracts;

interface TemplateModesInterface
{
    public function render_template();
}